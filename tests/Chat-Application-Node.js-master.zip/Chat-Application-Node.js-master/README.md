Chat App Assignment Node.js
===
 
A chat application built with Node.js and socket.io.

How to run
---
1. download the code then extract
2. run `npm install` from command line window
3. run `node server`
4. finnaly, open your browser and visit `localhost:3000

